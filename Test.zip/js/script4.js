let rand;
  (()=>{
    rand = Math.floor(Math.random() * (100 - 1)) + 1;
  })();
  const info = document.querySelector('.info');
  const input = document.querySelector('#text');
  const button = document.querySelector('.try');

  const rightnum = document.querySelector('#rightnum');
  const answer = document.querySelector('#answer');
  const attempts = document.querySelector('#attempts');
  console.log(rand);

  let count = 0;
  button.addEventListener('click', ()=>{
    if(input.value.length < 1) return '';
    answer.innerHTML += input.value+', ';
    rightnum.innerHTML = rand;
    count++;
    attempts.innerHTML = count;
    check(input.value, count);
    if (count == 5 || input.value == rand) {
      info.style.opacity = 1;
      button.disabled = true;
    }
    input.value = '';
  });

  function check(params, count) {
    const help = document.querySelector('.help');
    const help_h3 = document.querySelector('.help h3');
    if(params > rand){
      help.classList.remove('alert-secondary');
      help.classList.add('alert-warning');
      help_h3.innerHTML = 'Слишком много! '+' у вас '+ (5 - count) +'попыток осталось';
    }
    if(params < rand){
      help.classList.remove('alert-warning');
      help.classList.add('alert-secondary');
      help_h3.innerHTML = 'Слишком мало! '+' у вас '+ (5 - count) +' попыток осталось';
    }
    if (params == rand) {
      help.classList.add('alert-success');
      help_h3.innerHTML = 'Ты угадал число!';
    }
  };